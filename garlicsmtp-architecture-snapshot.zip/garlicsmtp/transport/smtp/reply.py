# Copyright (c) 2026 Giuliano Signorelli
# SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
#
# See LICENSE for the full license terms.

from dataclasses import dataclass


@dataclass(slots=True)
class SMTPServerReply:

    code: int

    message: str

    def capability(
        self,
        name: str,
    ) -> str | None:
        prefix = name + " "

        for line in self.message.splitlines():
            if line.startswith(prefix):
                return line[len(prefix):]

        return None